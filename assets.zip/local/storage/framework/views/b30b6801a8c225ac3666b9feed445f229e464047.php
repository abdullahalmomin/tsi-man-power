<!DOCTYPE html>
<html dir="ltr" lang="en-US">

<head>

    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="author" content="TSI MANPOWER" />


    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Raleway:300,400,500,600,700|Muli:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i|Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Crete+Round:400i" rel="stylesheet" type="text/css" />


    <!-- <link rel="stylesheet" type="text/css" href="css/styles-minify.css"> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles-minify.css')); ?>">


    <!-- <link rel="stylesheet" href="css/custom.css" type="text/css" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    
    <!-- <link rel="stylesheet" href="css/custom-project-02.css" type="text/css" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom-project-02.css')); ?>">



    <meta name="viewport" content="width=device-width, initial-scale=1" />


    <title>TSI MANPOWER</title>

    <!-- <link rel="icon" href="images/custom-images/logo/favi-logo-palace.png"> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/images/custom-images/logo/favi-logo-palace.png')); ?>">


</head>

<!-- <body data-loader-html="<img src='images/custom-images/logo/GPL-LOGO-animation-3.gif' alt='Loading Page' class='custom-loader'/>" class="stretched"> -->
<body data-loader-html="<img src='<?php echo e(asset('assets/vdo/preloader@2x.gif')); ?>' alt='Loading Page' class='custom-loader'/>" class="stretched">


<nav class="cd-vertical-nav">
    <ul>
        <li><a href="#palace-project-content" id="intro-nav"><span class="label">Hot Jobs</span></a></li>
        <li><a href="candidatesResume.html" id="location"><span class="label">Candidate Post Your Resume</span></a></li>
        <li><a href="#top-left-img-layout-plan" id="plan"><span class="label">Client post your Resume</span></a></li>
       <!--  <li><a href="#top-left-img-booking-form" id="booking"><span class="label">Booking</span></a></li>
        <li><a href="#top-left-img-term" id="term"><span class="label">Conditions</span></a></li>
 -->


    </ul>
</nav><!-- .cd-vertical-nav -->

<div id="wrapper" class="clearfix">



    <header id="header" class="transparent-header dark">

        <div id="header-wrap">

            <div class="container clearfix">

                <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

                <div id="logo">
                    <h3>TSI Manpower</h3>


                </div><!-- #logo end -->


                <nav id="primary-menu">

                    <ul>
                        <li class="current"><a href="#"><div class="primary-menu-ul-li-a-div"><i><img src="<?php echo e(asset('assets/images/custom-images/icon/Green-Planet-Lands-Ltd.png')); ?>" id="home-icon"></i>Home</div></a>

                        </li>

                        <li><a href="who-we-are.html"><div class="primary-menu-ul-li-a-div">About us </div></a>
                            <ul>
                                <li><a href="who-we-are.html#company-profile"><div class="primary-menu-ul-li-a-div">Company Profile</div></a>

                                </li>
                                <li><a href="who-we-are.html#message"><div class="primary-menu-ul-li-a-div">Introduction</div></a></li>

                                <li><a href="who-we-are.html#sister-concern"><div class="primary-menu-ul-li-a-div">Team</div></a></li>
                            </ul>
                             <li><a href="contact.html"><div class="primary-menu-ul-li-a-div"> Services</div></a></li>
                        <li><a href="contact.html"><div class="primary-menu-ul-li-a-div"> Cleints</div></a></li>
                        <li><a href="contact.html"><div class="primary-menu-ul-li-a-div">Govt. Services Division</div></a></li>
                        </li>

                   

                        <li><a href="contact.html"><div class="primary-menu-ul-li-a-div">Contact</div></a>

                        </li>

                    </ul>

                </nav><!-- #primary-menu end -->

            </div>

        </div>


    </header><!-- #header end -->
<!DOCTYPE html>
<html dir="ltr" lang="en-US">

<head>

    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="author" content="TSI MANPOWER" />


    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Raleway:300,400,500,600,700|Muli:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i|Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Crete+Round:400i" rel="stylesheet" type="text/css" />


    <!-- <link rel="stylesheet" type="text/css" href="css/styles-minify.css"> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles-minify.css')); ?>">


    <!-- <link rel="stylesheet" href="css/custom.css" type="text/css" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    
    <!-- <link rel="stylesheet" href="css/custom-project-02.css" type="text/css" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom-project-02.css')); ?>">



    <meta name="viewport" content="width=device-width, initial-scale=1" />


    <title>TSI MANPOWER</title>

    <!-- <link rel="icon" href="images/custom-images/logo/favi-logo-palace.png"> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/images/custom-images/logo/favi-logo-palace.png')); ?>">


</head>

<!-- <body data-loader-html="<img src='images/custom-images/logo/GPL-LOGO-animation-3.gif' alt='Loading Page' class='custom-loader'/>" class="stretched"> -->
<body data-loader-html="<img src='<?php echo e(asset('assets/vdo/preloader@2x.gif')); ?>' alt='Loading Page' class='custom-loader'/>" class="stretched">


<nav class="cd-vertical-nav">
    <ul>
        <li><a href="#palace-project-content" id="intro-nav"><span class="label">Hot Jobs</span></a></li>
        <li><a href="candidatesResume.html" id="location"><span class="label">Candidate Post Your Resume</span></a></li>
        <li><a href="#top-left-img-layout-plan" id="plan"><span class="label">Client post your Resume</span></a></li>
       <!--  <li><a href="#top-left-img-booking-form" id="booking"><span class="label">Booking</span></a></li>
        <li><a href="#top-left-img-term" id="term"><span class="label">Conditions</span></a></li>
 -->


    </ul>
</nav><!-- .cd-vertical-nav -->

<div id="wrapper" class="clearfix">



    <header id="header" class="transparent-header dark">

        <div id="header-wrap">

            <div class="container clearfix">

                <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

                <div id="logo">
                    <h3>TSI Manpower</h3>


                </div><!-- #logo end -->


                <nav id="primary-menu">

                    <ul>
                        <li class="current"><a href="#"><div class="primary-menu-ul-li-a-div"><i><img src="<?php echo e(asset('assets/images/custom-images/icon/Green-Planet-Lands-Ltd.png')); ?>" id="home-icon"></i>Home</div></a>

                        </li>

                        <li><a href="who-we-are.html"><div class="primary-menu-ul-li-a-div">About us </div></a>
                            <ul>
                                <li><a href="who-we-are.html#company-profile"><div class="primary-menu-ul-li-a-div">Company Profile</div></a>

                                </li>
                                <li><a href="who-we-are.html#message"><div class="primary-menu-ul-li-a-div">Introduction</div></a></li>

                                <li><a href="who-we-are.html#sister-concern"><div class="primary-menu-ul-li-a-div">Team</div></a></li>
                            </ul>
                             <li><a href="contact.html"><div class="primary-menu-ul-li-a-div"> Services</div></a></li>
                        <li><a href="contact.html"><div class="primary-menu-ul-li-a-div"> Cleints</div></a></li>
                        <li><a href="contact.html"><div class="primary-menu-ul-li-a-div">Govt. Services Division</div></a></li>
                        </li>

                   

                        <li><a href="contact.html"><div class="primary-menu-ul-li-a-div">Contact</div></a>

                        </li>

                    </ul>

                </nav><!-- #primary-menu end -->

            </div>

        </div>


    </header><!-- #header end -->
